// You might need this to handle communication between popup and content script
// if you are using a more complex timezone selection logic.
// For this simple example, it's not strictly necessary.
